# MakimaOS
Open in Android Studio, or push to GitHub: Actions -> Build APK -> download the MakimaOS-apk artifact.
Add any one (or all) of Gemini / Grok / DeepSeek keys in Settings, tap "Test Key", enable the Accessibility Service for phone control.
