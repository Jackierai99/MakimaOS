package com.makimaos.app
import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import androidx.core.content.ContextCompat

object Cmd {
    private val openWords = setOf("open", "launch", "start", "khol", "kholo", "kholna", "खोल", "खोलो", "चालू", "chalu", "chalao", "chala", "run")
    private val noise = setOf("makima", "please", "plz", "app", "the", "ko", "na", "do", "de", "dena", "karo", "kar", "ek", "zara", "jaldi", "mere", "liye", "mujhe", "ji", "boss", "जरा", "करो", "कर", "दो", "को", "ऐप")
    private val alias = mapOf("व्हाट्सएप" to "whatsapp", "व्हाट्सऐप" to "whatsapp", "यूट्यूब" to "youtube", "इंस्टाग्राम" to "instagram",
        "क्रोम" to "chrome", "कैमरा" to "camera", "सेटिंग" to "settings", "सेटिंग्स" to "settings", "गैलरी" to "gallery",
        "फोन" to "phone", "मैप्स" to "maps", "जीमेल" to "gmail", "स्पॉटिफाई" to "spotify", "टेलीग्राम" to "telegram", "फेसबुक" to "facebook")

    private fun start(ctx: Context, i: Intent) { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    fun tryHandle(ctx: Context, raw: String): String? {
        val t = raw.lowercase().trim()
        fun has(vararg k: String) = k.any { t.contains(it) }
        val svc = MakimaAccessibilityService.instance
        val need = "Boss, pehle Settings me MakimaOS Accessibility Service enable karo."
        fun g(a: Int, ok: String): String = if (svc == null) need else { svc.performGlobalAction(a); ok }

        Regex("(remember that|remember|yaad rakh(?:na|o)?|याद रख(?:ना|ो)?)", RegexOption.IGNORE_CASE).find(raw)?.let { m ->
            if (m.range.first < 4) {
                val fact = raw.removeRange(m.range).trim().trim('.', ',')
                if (fact.length > 2) { Prefs.memory = (Prefs.memory + "\n" + fact).trim(); return "Theek hai Boss, yaad rakh liya." }
            }
        }
        if (has("go home", "home screen", "home jao", "होम स्क्रीन")) return g(AccessibilityService.GLOBAL_ACTION_HOME, "Ho gaya Boss.")
        if (has("go back", "back jao", "peeche jao", "पीछे जाओ", "wapas jao")) return g(AccessibilityService.GLOBAL_ACTION_BACK, "Peeche aa gayi.")
        if (has("recent apps", "recents")) return g(AccessibilityService.GLOBAL_ACTION_RECENTS, "Recent apps, Boss.")
        if (has("notification")) return g(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, "Notifications khol di.")
        if (has("screenshot")) return g(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Screenshot le liya.")
        if (has("scroll down", "neeche scroll", "scroll neeche", "नीचे स्क्रॉल")) return if (svc == null) need else { svc.swipe(true); "Scroll down." }
        if (has("scroll up", "upar scroll", "scroll upar", "ऊपर स्क्रॉल")) return if (svc == null) need else { svc.swipe(false); "Scroll up." }
        Regex("^(click|tap|press|dabao|dabana|दबाओ)\\s+(on\\s+)?(.+)$").find(t)?.let { m ->
            val label = m.groupValues[3].trim()
            return if (svc == null) need else if (svc.clickText(label)) "Maine $label dabaya, Boss." else "Screen par '$label' nahi mila, Boss."
        }
        if (has("torch", "flashlight", "टॉर्च")) {
            val off = has(" off", "band", "बंद")
            return try {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], !off); if (off) "Torch band, Boss." else "Torch on, Boss."
            } catch (e: Exception) { "Torch nahi chala payi, Boss." }
        }
        val audio = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (has("volume up", "volume badha", "awaaz badha", "volume increase")) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); return "Volume badha diya." }
        if (has("volume down", "volume kam", "awaaz kam", "volume decrease")) { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return "Volume kam kar diya." }
        if (has("wifi settings", "wifi on", "wifi off", "wifi chalu", "wifi band")) { start(ctx, Intent(Settings.ACTION_WIFI_SETTINGS)); return "Wifi settings khol di." }
        if (has("bluetooth settings", "bluetooth on", "bluetooth off", "bluetooth chalu", "bluetooth band")) { start(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth settings khol di." }
        Regex("(call|dial)\\s+(\\+?[0-9 ]{5,})").find(t)?.let { m ->
            val num = m.groupValues[2].replace(" ", "")
            val ok = ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
            start(ctx, Intent(if (ok) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:$num")))
            return "Calling $num, Boss."
        }
        val tokens = t.split(Regex("\\s+"))
        if (tokens.any { it in openWords }) {
            val q = tokens.filter { it !in openWords && it !in noise }.joinToString(" ") { alias[it] ?: it }.trim()
            if (q.isNotEmpty()) { val label = openApp(ctx, q); if (label != null) return "$label khol rahi hoon, Boss." }
        }
        return null
    }

    private fun openApp(ctx: Context, q: String): String? {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { val l = it.loadLabel(pm).toString().lowercase(); l.contains(q) || (l.length > 2 && q.contains(l)) }
        val pkg = hit?.activityInfo?.packageName ?: return null
        val i = pm.getLaunchIntentForPackage(pkg) ?: return null
        start(ctx, i)
        return hit.loadLabel(pm).toString()
    }
}
