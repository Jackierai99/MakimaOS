package com.makimaos.app
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.roundToInt

private class Spot(val id: String, val x1: Int, val y1: Int, val x2: Int, val y2: Int)
private fun S(id: String, x1: Int, y1: Int, x2: Int, y2: Int) = Spot(id, x1, y1, x2, y2)

// Coordinates are in the 940 x 1672 reference space of the three screenshots.
private fun spots(t: MakimaTheme): List<Spot> = when (t) {
    MakimaTheme.PURPLE -> listOf(
        S("menu", 20, 70, 70, 120), S("eye", 95, 45, 205, 155), S("pro", 775, 70, 840, 125), S("settings", 850, 60, 920, 125),
        S("home", 0, 200, 105, 285), S("chat", 0, 290, 105, 375), S("voice", 0, 380, 105, 470), S("memory", 0, 475, 105, 565), S("settings", 0, 570, 105, 660),
        S("recent", 20, 960, 480, 1108),
        S("talk", 30, 1180, 285, 1250), S("ask", 30, 1260, 285, 1330), S("games", 295, 1180, 550, 1250), S("apps", 295, 1260, 550, 1330),
        S("v0", 670, 860, 755, 985), S("v1", 800, 860, 890, 985), S("v2", 670, 990, 755, 1115), S("v3", 800, 990, 890, 1115),
        S("recent", 575, 1145, 920, 1370),
        S("type", 225, 1395, 310, 1495), S("mic", 385, 1355, 555, 1525), S("voice", 635, 1395, 720, 1495),
        S("home", 80, 1550, 190, 1625), S("chat", 270, 1550, 370, 1625), S("eye", 430, 1550, 515, 1625), S("gallery", 590, 1550, 690, 1625), S("profile", 760, 1550, 850, 1625))
    MakimaTheme.RED -> listOf(
        S("menu", 30, 75, 75, 115), S("eye", 100, 55, 195, 140), S("settings", 780, 65, 825, 110), S("pro", 850, 65, 915, 125),
        S("chat", 15, 565, 97, 660), S("voice", 15, 675, 97, 770), S("memory", 15, 785, 97, 880), S("settings", 15, 890, 97, 1000),
        S("recent", 650, 480, 925, 550),
        S("v0", 710, 810, 805, 945), S("v1", 820, 810, 910, 945), S("v2", 710, 960, 805, 1095), S("v3", 820, 960, 910, 1095),
        S("talk", 15, 1112, 400, 1203),
        S("c1", 720, 1155, 920, 1195), S("c2", 720, 1205, 920, 1245), S("c3", 720, 1255, 920, 1295), S("c4", 720, 1305, 920, 1345),
        S("type", 225, 1320, 320, 1430), S("mic", 365, 1265, 580, 1480), S("voice", 620, 1320, 715, 1430),
        S("home", 130, 1545, 215, 1620), S("chat", 285, 1545, 370, 1620), S("eye", 430, 1545, 510, 1620), S("gallery", 570, 1545, 655, 1620), S("profile", 725, 1545, 815, 1620))
    MakimaTheme.BLUE -> listOf(
        S("menu", 30, 70, 70, 110), S("eye", 100, 45, 195, 140), S("settings", 755, 62, 825, 120), S("pro", 835, 62, 920, 120),
        S("home", 0, 300, 110, 390), S("chat", 0, 395, 110, 490), S("voice", 0, 495, 110, 585), S("memory", 0, 590, 110, 685), S("settings", 0, 690, 110, 780),
        S("recent", 670, 610, 925, 685),
        S("v0", 690, 800, 795, 935), S("v1", 805, 800, 915, 935), S("v2", 690, 965, 795, 1100), S("v3", 805, 965, 915, 1100),
        S("talk", 35, 960, 340, 1030), S("ask", 35, 1035, 340, 1105), S("games", 35, 1110, 340, 1180), S("apps", 35, 1185, 340, 1255),
        S("recent", 585, 1150, 925, 1420),
        S("mic", 345, 1295, 520, 1470),
        S("home", 110, 1520, 210, 1620), S("chat", 270, 1520, 370, 1620), S("voice", 430, 1520, 510, 1620), S("gallery", 580, 1520, 670, 1620), S("profile", 740, 1520, 820, 1620))
}

private fun micPos(t: MakimaTheme): Triple<Int, Int, Int> = when (t) {
    MakimaTheme.PURPLE -> Triple(470, 1440, 95)
    MakimaTheme.RED -> Triple(470, 1370, 110)
    MakimaTheme.BLUE -> Triple(432, 1385, 90)
}

private fun act(a: AppState, id: String) {
    when (id) {
        "eye" -> a.cycleTheme()
        "menu", "settings" -> a.screen = Screen.SETTINGS
        "pro", "profile" -> a.screen = Screen.PROFILE
        "chat", "recent", "type", "ask" -> a.screen = Screen.CHAT
        "voice", "mic", "talk" -> a.toggleListen()
        "memory" -> a.screen = Screen.MEMORY
        "gallery" -> a.screen = Screen.GALLERY
        "games" -> a.send("Let's play a fun quick game, Makima.")
        "apps" -> a.say("Kaunsa app kholna hai, Boss? Mic dabao aur bolo.")
        "v0" -> a.pickVoice(0)
        "v1" -> a.pickVoice(1)
        "v2", "v3" -> a.pickVoice(2)
        "c1" -> a.send("Tell me something interesting.")
        "c2" -> a.send("What can you do?")
        "c3" -> a.send("Let's play a game.")
        "c4" -> a.send("Just talk to me for a bit.")
    }
}

@Composable
fun HomeScreen(app: AppState) {
    val t = app.theme
    val painter = painterResource(t.bg)
    val inf = rememberInfiniteTransition(label = "inf")
    val breathe by inf.animateFloat(1f, 1.012f, infiniteRepeatable(tween(3500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val pulse by inf.animateFloat(0.92f, 1.12f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "pulse")
    val d = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val w = constraints.maxWidth.toFloat(); val h = constraints.maxHeight.toFloat()
        val iw = painter.intrinsicSize.width; val ih = painter.intrinsicSize.height
        val s = max(w / iw, h / ih)
        val ox = (w - iw * s) / 2f; val oy = (h - ih * s) / 2f
        fun px(x: Float) = ox + x / 940f * iw * s
        fun py(y: Float) = oy + y / 1672f * ih * s
        Image(painter, null, Modifier.fillMaxSize().graphicsLayer { scaleX = breathe; scaleY = breathe }, contentScale = ContentScale.Crop)

        if (app.listening || app.thinking || app.mouth.speaking) {
            val (cx, cy, r) = micPos(t)
            val lvl = if (app.listening) app.level else 0f
            val rad = r / 940f * iw * s * (if (app.listening) 1f + lvl * 0.25f else pulse)
            Canvas(Modifier.fillMaxSize()) {
                drawCircle(t.accent.copy(alpha = 0.9f), rad, Offset(px(cx.toFloat()), py(cy.toFloat())), style = Stroke(7f))
                drawCircle(t.accent.copy(alpha = 0.3f), rad * 1.25f, Offset(px(cx.toFloat()), py(cy.toFloat())), style = Stroke(4f))
            }
        }

        for (sp in spots(t)) {
            Box(
                Modifier
                    .offset { IntOffset(px(sp.x1.toFloat()).roundToInt(), py(sp.y1.toFloat()).roundToInt()) }
                    .size(with(d) { (px(sp.x2.toFloat()) - px(sp.x1.toFloat())).toDp() }, with(d) { (py(sp.y2.toFloat()) - py(sp.y1.toFloat())).toDp() })
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { act(app, sp.id) }
            )
        }

        val text = when {
            app.listening -> if (app.partial.isBlank()) "Listening..." else app.partial
            app.thinking -> "Thinking..."
            else -> app.bubble
        }
        if (text.isNotBlank()) {
            val shape = RoundedCornerShape(18.dp)
            Box(
                Modifier.align(Alignment.TopCenter)
                    .padding(top = with(d) { (h * 0.40f).toDp() }, start = with(d) { (w * 0.14f).toDp() }, end = 16.dp)
                    .clip(shape).background(Color(0xB3000000)).border(1.dp, t.accent, shape)
                    .clickable { app.bubble = "" }.padding(14.dp)
            ) { Text(text, color = Color.White, fontSize = 15.sp, maxLines = 7) }
        }
    }
}
