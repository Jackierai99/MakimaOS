package com.makimaos.app
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun Page(app: AppState, title: String, content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(app.theme.bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Color(0xDD000000)))
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { app.screen = Screen.HOME }) { Icon(Icons.Default.ArrowBack, null, tint = Color.White) }
                Image(painterResource(R.drawable.logo), null, Modifier.size(40.dp).clip(CircleShape))
                Spacer(Modifier.width(10.dp))
                Text(title, color = app.theme.accent, fontSize = 22.sp)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
fun Chip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(if (selected) accent.copy(alpha = 0.35f) else Color(0x33FFFFFF))
        .border(1.dp, if (selected) accent else Color(0x44FFFFFF), shape).clickable { onClick() }.padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String, accent: Color, secret: Boolean = false, modifier: Modifier = Modifier) {
    OutlinedTextField(value, onChange, modifier = modifier, label = { Text(label) }, singleLine = true,
        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            focusedBorderColor = accent, unfocusedBorderColor = Color(0x66FFFFFF), focusedLabelColor = accent, unfocusedLabelColor = Color(0xAAFFFFFF), cursorColor = accent))
}

@Composable
fun ChatScreen(app: AppState) {
    val t = app.theme
    var input by remember { mutableStateOf("") }
    val ls = rememberLazyListState()
    LaunchedEffect(app.messages.size) { if (app.messages.isNotEmpty()) ls.animateScrollToItem(app.messages.size - 1) }
    Page(app, "MAKIMA OS") {
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(app.messages) { m ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.user) Arrangement.End else Arrangement.Start) {
                    Box(Modifier.widthIn(max = 290.dp).clip(RoundedCornerShape(16.dp))
                        .background(if (m.user) t.accent.copy(alpha = 0.4f) else Color(0x66FFFFFF).copy(alpha = 0.15f)).padding(12.dp)) {
                        Text(m.text, color = Color.White, fontSize = 15.sp)
                    }
                }
            }
            if (app.thinking) item { Text("Makima is thinking...", color = Color(0xAAFFFFFF), fontSize = 13.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, "Type to Makima", t.accent, modifier = Modifier.weight(1f))
            IconButton(onClick = { app.toggleListen() }) { Icon(Icons.Default.Mic, null, tint = if (app.listening) t.accent else Color.White) }
            IconButton(onClick = { app.send(input); input = "" }) { Icon(Icons.Default.Send, null, tint = t.accent) }
        }
    }
}

@Composable
fun KeyBlock(app: AppState, p: String) {
    val t = app.theme
    val scope = rememberCoroutineScope()
    var key by remember { mutableStateOf(Prefs.key(p)) }
    var model by remember { mutableStateOf(Prefs.model(p)) }
    var res by remember { mutableStateOf("") }
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x33FFFFFF)).padding(12.dp)) {
        Text("$p API Key", color = Color.White, fontSize = 16.sp)
        Field(key, { key = it; Prefs.setKey(p, it) }, "$p API Key", t.accent, secret = true, modifier = Modifier.fillMaxWidth())
        Field(model, { model = it; Prefs.setModel(p, it) }, "$p Model", t.accent, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Button(onClick = {
            scope.launch { res = "Testing..."; res = withContext(Dispatchers.IO) { Brain.test(p) } }
        }, colors = ButtonDefaults.buttonColors(containerColor = t.accent)) { Text("Test $p Key", color = Color.White) }
        if (res.isNotEmpty()) Text(res, color = if (res.startsWith("Working")) Color(0xFF7CFFA0) else Color(0xFFFF8A8A), fontSize = 13.sp)
    }
}

@Composable
fun SettingsScreen(app: AppState) {
    val t = app.theme
    val ctx = app.ctx
    var primary by remember { mutableStateOf(Prefs.primary) }
    Page(app, "Settings") {
        Column(Modifier.verticalScroll(rememberScrollState())) {
            Text("API Keys (any one key is enough)", color = Color.White, fontSize = 18.sp)
            Prefs.providers.forEach { KeyBlock(app, it) }
            Text("Primary Brain", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                Prefs.providers.forEach { p -> Chip(p, primary == p, t.accent) { primary = p; Prefs.primary = p } }
            }
            Text("Voice", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                listOf("Voice 1 Calm", "Voice 2 Soft", "Voice 3 Cold").forEachIndexed { i, n -> Chip(n, app.voice == i, t.accent) { app.pickVoice(i) } }
            }
            Text("Theme", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                MakimaTheme.values().forEach { m -> Chip(m.label, app.theme == m, t.accent) { app.setTheme(m) } }
            }
            Text("Phone Control", color = Color.White, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
            Text("Accessibility Service: " + if (MakimaAccessibilityService.instance != null) "Enabled" else "Disabled (turn on MakimaOS Control)",
                color = Color(0xCCFFFFFF), fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) },
                    colors = ButtonDefaults.buttonColors(containerColor = t.accent)) { Text("Open Accessibility") }
                Button(onClick = { app.askPerms() }, colors = ButtonDefaults.buttonColors(containerColor = t.accent)) { Text("Grant Permissions") }
            }
            Text("Try: open WhatsApp, go home, scroll down, click Search, torch on, volume up, call 9876543210, remember my birthday is 5 May.",
                color = Color(0x99FFFFFF), fontSize = 12.sp)
            Spacer(Modifier.height(40.dp))
        }
    }
}

@Composable
fun MemoryScreen(app: AppState) {
    var lines by remember { mutableStateOf(Prefs.memory.lines().filter { it.isNotBlank() }) }
    var input by remember { mutableStateOf("") }
    fun save(l: List<String>) { lines = l; Prefs.memory = l.joinToString("\n") }
    Page(app, "Memory") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Field(input, { input = it }, "Tell Makima to remember", app.theme.accent, modifier = Modifier.weight(1f))
            IconButton(onClick = { if (input.isNotBlank()) { save(lines + input.trim()); input = "" } }) { Icon(Icons.Default.Add, null, tint = app.theme.accent) }
        }
        LazyColumn(Modifier.weight(1f)) {
            items(lines) { l ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x33FFFFFF)).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(l, color = Color.White, modifier = Modifier.weight(1f))
                    IconButton(onClick = { save(lines - l) }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF8A8A)) }
                }
            }
        }
    }
}

@Composable
fun GalleryScreen(app: AppState) {
    Page(app, "Gallery") {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            MakimaTheme.values().forEach { m ->
                Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(16.dp))
                    .border(2.dp, if (app.theme == m) m.accent else Color.Transparent, RoundedCornerShape(16.dp))
                    .clickable { app.setTheme(m); app.screen = Screen.HOME }) {
                    Image(painterResource(m.bg), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alignment = Alignment.TopCenter)
                    Text(m.label, color = Color.White, fontSize = 18.sp, modifier = Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(8.dp))
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(app: AppState) {
    var name by remember { mutableStateOf(Prefs.userName) }
    Page(app, "Profile") {
        Field(name, { name = it; Prefs.userName = it }, "What should Makima call you?", app.theme.accent, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Image(painterResource(R.drawable.logo), null, Modifier.size(160.dp).clip(CircleShape).align(Alignment.CenterHorizontally))
        Text("MakimaOS v1.0", color = Color(0xAAFFFFFF))
        Text("Brain used last: ${Brain.lastUsed.ifEmpty { "none yet" }}", color = Color(0xAAFFFFFF))
    }
}
