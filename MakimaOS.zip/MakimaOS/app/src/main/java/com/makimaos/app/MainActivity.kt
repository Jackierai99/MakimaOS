package com.makimaos.app
import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.view.WindowCompat

class MainActivity : ComponentActivity() {
    private var app: AppState? = null
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Prefs.init(applicationContext)
        val a = AppState(this); app = a
        setContent {
            val mic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) a.startListening() }
            val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
            LaunchedEffect(Unit) {
                a.askMic = { mic.launch(Manifest.permission.RECORD_AUDIO) }
                a.askPerms = { perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE)) }
            }
            BackHandler(a.screen != Screen.HOME) { a.screen = Screen.HOME }
            when (a.screen) {
                Screen.HOME -> HomeScreen(a)
                Screen.CHAT -> ChatScreen(a)
                Screen.SETTINGS -> SettingsScreen(a)
                Screen.MEMORY -> MemoryScreen(a)
                Screen.GALLERY -> GalleryScreen(a)
                Screen.PROFILE -> ProfileScreen(a)
            }
        }
    }
    override fun onDestroy() { app?.release(); super.onDestroy() }
}
