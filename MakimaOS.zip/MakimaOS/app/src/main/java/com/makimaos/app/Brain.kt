package com.makimaos.app
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    var lastUsed = ""

    private fun system(): String {
        val mem = Prefs.memory.trim()
        return "You are Makima from Chainsaw Man, acting as the personal AI voice assistant of your user, whom you call '${Prefs.userName}'. " +
            "Personality: calm, composed, elegant, softly dominant, subtly teasing, caring in a quiet way. " +
            "Reply in Hinglish (Hindi written in Roman letters mixed with English) unless the user writes only in English or in Devanagari, then match them. " +
            "Keep replies short (1 to 3 sentences) because they are spoken aloud. No markdown, no emojis, no lists. " +
            "Be genuinely helpful and accurate for every question." +
            (if (mem.isNotEmpty()) "\nFacts you know about the user:\n$mem" else "")
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 45000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP $code: ${text.take(220)}")
        return text
    }

    private fun call(p: String, msgs: List<Pair<String, String>>): String {
        val key = Prefs.key(p); val model = Prefs.model(p)
        val out = if (p == "Gemini") {
            val contents = JSONArray()
            msgs.forEach { (r, t) ->
                contents.put(JSONObject().put("role", if (r == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", t))))
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
                .put("contents", contents).toString()
            val res = post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key", emptyMap(), body)
            JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                .getJSONArray("parts").getJSONObject(0).getString("text")
        } else {
            val url = if (p == "Grok") "https://api.x.ai/v1/chat/completions" else "https://api.deepseek.com/chat/completions"
            val arr = JSONArray().put(JSONObject().put("role", "system").put("content", system()))
            msgs.forEach { (r, t) -> arr.put(JSONObject().put("role", if (r == "user") "user" else "assistant").put("content", t)) }
            val body = JSONObject().put("model", model).put("messages", arr).toString()
            val res = post(url, mapOf("Authorization" to "Bearer $key"), body)
            JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
        return out.trim()
    }

    fun ask(msgs: List<Pair<String, String>>): String {
        val order = (listOf(Prefs.primary) + Prefs.providers.filter { it != Prefs.primary }).filter { Prefs.key(it).isNotBlank() }
        if (order.isEmpty()) return "Boss, Settings me kam se kam ek API key daalo, phir main bolungi."
        var err = ""
        for (p in order) {
            try { val r = call(p, msgs); lastUsed = p; return r } catch (e: Exception) { err = "$p: ${e.message}" }
        }
        return "Boss, saare brains fail ho gaye. $err"
    }

    fun test(p: String): String {
        if (Prefs.key(p).isBlank()) return "Enter a key first."
        return try { "Working: " + call(p, listOf("user" to "Reply with exactly the word OK")).take(60) }
        catch (e: Exception) { "Failed: ${e.message}" }
    }
}
