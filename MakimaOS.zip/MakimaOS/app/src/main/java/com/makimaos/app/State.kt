package com.makimaos.app
import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

class Msg(val user: Boolean, val text: String)
enum class Screen { HOME, CHAT, SETTINGS, MEMORY, GALLERY, PROFILE }

class AppState(val ctx: Context) {
    var theme by mutableStateOf(MakimaTheme.values()[Prefs.theme.coerceIn(0, 2)])
    var screen by mutableStateOf(Screen.HOME)
    val messages = mutableStateListOf<Msg>()
    var listening by mutableStateOf(false)
    var thinking by mutableStateOf(false)
    var partial by mutableStateOf("")
    var bubble by mutableStateOf("")
    var level by mutableStateOf(0f)
    var voice by mutableStateOf(Prefs.voice)
    var askMic: () -> Unit = {}
    var askPerms: () -> Unit = {}
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    val mouth = Mouth(ctx)
    private val ears = Ears(ctx,
        onPartial = { partial = it },
        onFinal = { listening = false; partial = ""; send(it) },
        onEnd = { listening = false; partial = "" },
        onLevel = { level = it })

    fun setTheme(t: MakimaTheme) { theme = t; Prefs.theme = t.ordinal }
    fun cycleTheme() = setTheme(theme.next())
    fun pickVoice(i: Int, sample: Boolean = true) {
        voice = i; Prefs.voice = i
        if (sample) say("Main Makima hoon, Boss. Ab se meri awaaz yehi hogi.")
    }
    fun say(t: String) { bubble = t; mouth.speak(t, voice) }

    fun toggleListen() {
        if (listening) { ears.stop(); listening = false; return }
        startListening()
    }
    fun startListening() {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { askMic(); return }
        mouth.stop(); partial = ""; listening = true; ears.start()
    }

    fun send(text: String) {
        if (text.isBlank()) return
        messages.add(Msg(true, text)); thinking = true; bubble = ""
        scope.launch {
            val local = try { Cmd.tryHandle(ctx, text) } catch (e: Exception) { "Boss, command me error: ${e.message}" }
            val reply = local ?: withContext(Dispatchers.IO) {
                val hist = messages.takeLast(12).map { (if (it.user) "user" else "model") to it.text }.dropWhile { it.first != "user" }
                try { Brain.ask(hist) } catch (e: Exception) { "Boss, error: ${e.message}" }
            }
            messages.add(Msg(false, reply)); thinking = false
            say(reply)
        }
    }
    fun release() { ears.stop(); mouth.release(); scope.cancel() }
}
