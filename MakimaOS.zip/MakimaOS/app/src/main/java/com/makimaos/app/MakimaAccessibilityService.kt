package com.makimaos.app
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class MakimaAccessibilityService : AccessibilityService() {
    companion object { var instance: MakimaAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun clickText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label) ?: return false
        for (n in nodes) {
            var c: AccessibilityNodeInfo? = n
            while (c != null && !c.isClickable) c = c.parent
            if (c != null) { c.performAction(AccessibilityNodeInfo.ACTION_CLICK); return true }
        }
        return false
    }

    fun swipe(up: Boolean) {
        val m = resources.displayMetrics
        val x = m.widthPixels / 2f
        val a = m.heightPixels * (if (up) 0.7f else 0.3f)
        val b = m.heightPixels * (if (up) 0.3f else 0.7f)
        val path = Path().apply { moveTo(x, a); lineTo(x, b) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 300)).build(), null, null)
    }
}
