package com.makimaos.app
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

class Mouth(ctx: Context) {
    var speaking by mutableStateOf(false)
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private val tts: TextToSpeech = TextToSpeech(ctx) { ready = it == TextToSpeech.SUCCESS }

    fun speak(text: String, idx: Int) {
        if (!ready) return
        val clean = text.replace(Regex("[*_#`~>]"), " ").replace(Regex("[\\p{So}\\p{Cs}]"), "").trim()
        if (clean.isEmpty()) return
        val deva = clean.any { it in '\u0900'..'\u097F' }
        val loc = if (deva) Locale("hi", "IN") else Locale("en", "IN")
        tts.language = loc
        val cand = (tts.voices ?: emptySet()).filter { it.locale.language == loc.language && it.features?.contains("notInstalled") != true }
        val fem = cand.filter { it.name.contains("female", true) }.ifEmpty { cand }
        if (fem.isNotEmpty()) tts.voice = fem[idx % fem.size]
        val (pitch, rate) = when (idx) { 0 -> 1.12f to 0.92f; 1 -> 1.3f to 1.0f; else -> 1.0f to 0.88f }
        tts.setPitch(pitch); tts.setSpeechRate(rate)
        val chunks = clean.chunked(3500)
        val lastId = "mk${chunks.size - 1}"
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) { main.post { speaking = true } }
            override fun onDone(id: String?) { if (id == lastId) main.post { speaking = false } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { speaking = false } }
        })
        chunks.forEachIndexed { i, c -> tts.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "mk$i") }
    }
    fun stop() { tts.stop(); speaking = false }
    fun release() { tts.stop(); tts.shutdown() }
}

class Ears(private val ctx: Context, private val onPartial: (String) -> Unit, private val onFinal: (String) -> Unit,
           private val onEnd: () -> Unit, private val onLevel: (Float) -> Unit) {
    private var sr: SpeechRecognizer? = null
    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onEnd(); return }
        stop()
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rms: Float) { onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(e: Int) { onEnd() }
                override fun onResults(r: Bundle?) {
                    val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    if (t.isBlank()) onEnd() else onFinal(t)
                }
                override fun onPartialResults(r: Bundle?) {
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onPartial(it) }
                }
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        sr?.startListening(i)
    }
    fun stop() { sr?.cancel(); sr?.destroy(); sr = null }
}
