package com.makimaos.app
import androidx.compose.ui.graphics.Color

enum class MakimaTheme(val label: String, val bg: Int, val accent: Color) {
    PURPLE("Purple Night", R.drawable.bg_purple, Color(0xFFB04CFF)),
    RED("Crimson Control", R.drawable.bg_red, Color(0xFFFF3B4A)),
    BLUE("Sky Blue", R.drawable.bg_blue, Color(0xFF29B6FF));
    fun next() = values()[(ordinal + 1) % values().size]
}
