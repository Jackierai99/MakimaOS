package com.makimaos.app
import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("makimaos", Context.MODE_PRIVATE) }
    val providers = listOf("Gemini", "Grok", "DeepSeek")
    private val defaultModels = mapOf("Gemini" to "gemini-2.0-flash", "Grok" to "grok-3", "DeepSeek" to "deepseek-chat")
    fun key(p: String): String = sp.getString("key_$p", "") ?: ""
    fun setKey(p: String, v: String) { sp.edit().putString("key_$p", v.trim()).apply() }
    fun model(p: String): String {
        val m = sp.getString("model_$p", null)
        return if (m.isNullOrBlank()) defaultModels.getValue(p) else m
    }
    fun setModel(p: String, v: String) { sp.edit().putString("model_$p", v.trim()).apply() }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var voice: Int
        get() = sp.getInt("voice", 0)
        set(v) { sp.edit().putInt("voice", v).apply() }
    var primary: String
        get() = sp.getString("primary", "Gemini") ?: "Gemini"
        set(v) { sp.edit().putString("primary", v).apply() }
    var userName: String
        get() = sp.getString("name", "Boss") ?: "Boss"
        set(v) { sp.edit().putString("name", v).apply() }
    var memory: String
        get() = sp.getString("memory", "") ?: ""
        set(v) { sp.edit().putString("memory", v).apply() }
}
